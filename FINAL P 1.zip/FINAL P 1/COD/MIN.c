//This project was implemented using (PIC16F877A)
//and programmed by ( Mikroc Pro for pic )

//Sensor: XW-040 Sensor (or what is known as "Soil Moisture Sensor Module" tutorial with Arduino.
//HC-05 Communication Module

// Define LCD pins
sbit LCD_RS at RB0_bit;
sbit LCD_EN at RB1_bit;
sbit LCD_D4 at RB2_bit;
sbit LCD_D5 at RB3_bit;
sbit LCD_D6 at RB4_bit;
sbit LCD_D7 at RB5_bit;

sbit LCD_RS_Direction at TRISB0_bit;
sbit LCD_EN_Direction at TRISB1_bit;
sbit LCD_D4_Direction at TRISB2_bit;
sbit LCD_D5_Direction at TRISB3_bit;
sbit LCD_D6_Direction at TRISB4_bit;
sbit LCD_D7_Direction at TRISB5_bit;

unsigned int soil_moisture_value;
char display_text[16];
char mode = 0;
char bt_data;

// Define Relay pin for Water Pump (connected to RC0)
sbit RELAY at RC0_bit;
sbit RELAY_Direction at TRISC0_bit;

void update_display() {
    Lcd_Out(1, 1, "Moisture:");
    Lcd_Out(1, 10, display_text);


    if (mode == 0) Lcd_Out(2, 1, "Mode:Auto  ");
    else if (mode == 1) Lcd_Out(2, 1, "Mode:ManualON ");
    else if (mode == 2) Lcd_Out(2, 1, "Mode:ManualOFF");


    if (RELAY == 0) Lcd_Out(2, 13, "OFF");
    else Lcd_Out(2, 13, " ON");
}

void main() {
    // Initialize LCD
    Lcd_Init();
    Lcd_Cmd(_LCD_CLEAR);
    Lcd_Cmd(_LCD_CURSOR_OFF);

    // Initialize ADC for soil moisture sensor
    ADCON1 = 0x80;
    TRISA = 0xFF;

    // Initialize UART1 for Bluetooth (9600 baud rate)
    UART1_Init(9600);
    Delay_ms(100);

    // Step 1: Display project name
    Lcd_Out(1, 1, "SMART IRRIGATION");
    Lcd_Out(2, 1, "   SYSTEM START   ");

    UART1_Write_Text("SMART IRRIGATION SYSTEM BY GROUP M");
    UART1_Write(13);  // Carriage return
    UART1_Write(10);  // Newline

    Delay_ms(1000);
    Lcd_Cmd(_LCD_CLEAR);

    // Set RC0 (relay) as output
    RELAY_Direction = 0;
    RELAY = 0;  // Initially turn off pump
    mode = 0;   // Start in auto mode

    while (1) {
        // Check Bluetooth commands
        if (UART1_Data_Ready()) {
            bt_data = UART1_Read();

            if (bt_data == '1') {
                mode = 1;
                RELAY = 1;  // Force pump ON
            }
            else if (bt_data == '2') {
                mode = 2;
                RELAY = 0;  // Force pump OFF
            }
            else if (bt_data == '3') {
                mode = 0;  // Return to auto mode
            }
        }

        // Read soil moisture
        soil_moisture_value = ADC_Read(0);
        IntToStr(soil_moisture_value, display_text);

        // Auto mode control logic
        if (mode == 0) {
            if (soil_moisture_value <= 400) {
                RELAY = 0;  // Turn OFF pump
            } else {
                RELAY = 1;  // Turn ON pump
            }
        }

        // Update display and send data via Bluetooth
        update_display();

        // Send status via Bluetooth
        UART1_Write_Text("M:");
        UART1_Write_Text(display_text);
        UART1_Write_Text(" Mode:");

        if (mode == 0) UART1_Write_Text("Auto");
        else if (mode == 1) UART1_Write_Text("ManualON");
        else if (mode == 2) UART1_Write_Text("ManualOFF");

        UART1_Write_Text(" Pump:");
        if (RELAY == 0) UART1_Write_Text("OFF");
        else UART1_Write_Text("ON");

        UART1_Write(13);
        UART1_Write(10);

        Delay_ms(1000);
    }
}